---
name: cybersecurity-cv-analyzer
description: This skill should be used when analyzing a single cybersecurity CV objectively to understand the candidate's true profile, strengths, and experience. Use when asked to assess ONE candidate's capabilities, identify their dominant security domain, evaluate certifications, detect red flags, or provide career development recommendations. Analyzes CVs individually, one at a time. Does NOT compare multiple candidates.
---

# Cybersecurity CV Analyzer

## Purpose

Analyze and evaluate **a single cybersecurity professional's CV objectively** to understand who the candidate really is. This skill provides structured assessment across 24 specialized dimensions to identify:
- The candidate's dominant security domain (Offensive, Defensive, Cloud, GRC, etc.)
- True seniority level based on experience and depth
- Strengths and development areas
- Red flags or inconsistencies
- Suitable career paths
- Market value estimation

**Important**: This skill analyzes ONE candidate at a time objectively, NOT their fit for a specific role. It answers "Who is this person?" not "Does this person fit role X?"

**Scope**: Individual CV analysis only. Does NOT compare multiple candidates.

## When to Use

Invoke this skill when the user requests analysis of **ONE CV**:

- **Objective CV analysis**: "Analyze this CV" or "What's this candidate's profile?"
- **Candidate profiling**: "What kind of security professional is this?"
- **Strength identification**: "What are this person's strongest areas?"
- **Red flag detection**: "Are there any concerns with this CV?"
- **Career guidance**: "What certifications should they pursue?"
- **Salary estimation**: "What's this person's market value?"
- **Development planning**: "What should they work on to advance?"

## When NOT to Use

**Do NOT use this skill for**:
- **Multi-candidate comparison**: "Compare these 3 CVs" - this skill analyzes one CV at a time
- **Role-specific fit analysis**: "Does this person fit our Pentester role?" - that's a separate analysis
- **Batch processing**: Analyze each CV individually, not in bulk

## Core Workflow

Analyze the candidate objectively WITHOUT considering any specific role requirements. The goal is to understand who the candidate really is.

### 1. Read the CV

When presented with a CV file:

**IMPORTANT - Use Specialized Skills for Document Reading**:

**For PDF files (.pdf)**:
- ✅ **ALWAYS use the `pdf` skill** to extract text
- ❌ **NEVER use the Read tool** - it doesn't properly extract text from PDFs
- The `pdf` skill uses libraries like `pypdf` and `pdfplumber` for proper extraction

**For Word documents (.docx)**:
- ✅ **ALWAYS use the `docx` skill** to extract text
- ❌ **NEVER use the Read tool** - it doesn't properly extract text from DOCX files
- The `docx` skill properly handles Word document formatting and structure

**For plain text files (.txt, .md)**:
- ✅ Use the Read tool directly

**Why this matters**: The Read tool shows visual representations of PDFs/DOCX but doesn't extract the actual text content properly. The specialized `pdf` and `docx` skills have the proper libraries to extract structured text.

Extract and identify:
- Contact information (email, phone, LinkedIn)
- Certifications (look for OSCP, CISSP, CEH, AWS Security, etc.)
- Years of experience (total and per technology)
- Education and degrees
- Technical skills, tools, and frameworks
- Work history with titles and companies
- Projects and achievements

### 2. Score Across 24 Dimensions (Objective - No Role Bias)

Evaluate the candidate on a 0-10 scale across these dimensions **based solely on what the CV shows**, not what any role requires:

**Core Technical (1-12)**:
1. **Certifications**: Count and value certs using `references/certifications_db.md`
2. **Years of Experience**: Total years in cybersecurity
3. **Offensive Skills**: Pentesting, red team, exploitation
4. **Defensive Skills**: SOC, incident response, threat hunting
5. **Governance & Compliance**: Frameworks, audits, policies
6. **Cloud Security**: AWS/Azure/GCP security knowledge
7. **Technical Tools**: SIEM, EDR, scanners, pentesting tools
8. **Programming & Scripting**: Python, PowerShell, Bash, etc.
9. **Architecture & Secure Design**: Security architecture, Zero Trust
10. **Education**: Degrees and formal training
11. **Soft Skills**: Leadership, communication, management
12. **Languages**: English proficiency, multilingual

**Specialized (13-24)**:
13. DevSecOps & CI/CD Security
14. Forensics & Malware Analysis
15. Cryptography Applied
16. OT/ICS Security
17. Mobile & IoT Security
18. Threat Intelligence
19. Community Contributions
20. Publications & Research
21. Management & Strategy
22. Crisis Management
23. Transformation & Change
24. Niche Specialties

Consult `references/scoring_rubric.md` for detailed criteria per dimension.

## CRITICAL: Handling Missing Evidence

**When a dimension cannot be evaluated from the CV** (no mentions, no evidence):

**Option 1 - Mark as "Not Evaluated" (PREFERRED)**:
- Score: **"N/E"** (Not Evaluated)
- Meaning: "No evidence in CV to assess this dimension"
- Use this for specialized dimensions where absence doesn't mean incompetence

**Option 2 - Default Low Score (ALTERNATIVE)**:
- Score: **0-2/10**
- Meaning: "No evidence shown, assume minimal/no capability"
- Use this when the skill is expected for their seniority level but not shown

**Examples**:

**GOOD handling**:
```
- Offensive Skills: 8.5/10 (OSCP, 5 years pentesting, detailed project descriptions)
- Defensive Skills: N/E (No SOC/IR experience mentioned in CV)
- OT/ICS Security: N/E (No industrial security mentioned)
- Publications: 0/10 (Expected at Senior level but none shown)
- Management: 3/10 (Mentions "mentored 2 juniors" but no formal leadership)
```

**BAD handling**:
```
- Offensive Skills: 8.5/10
- Defensive Skills: 5/10 (guessing they probably have some)
- OT/ICS Security: 4/10 (assuming average)
```

**Rules**:
1. **Only score what you can see**: If CV doesn't mention it, don't guess
2. **Distinguish absence from incompetence**: "N/E" means "not shown", not "bad at it"
3. **Flag low-confidence scores**: When inferring from limited evidence, note it
4. **Report evidence quality**: For each scored dimension, briefly note the evidence

**Include in output**:
```
## Scoring Confidence

High Confidence (strong evidence):
- Offensive Skills: 8.5/10 (OSCP cert, 5 years pentesting, 10+ projects detailed)
- Cloud Security: 7.2/10 (AWS Security cert, 3 years AWS, describes architectures)

Medium Confidence (some evidence):
- Programming: 6.5/10 (Lists Python/Bash, one automation project described)
- Soft Skills: 5.5/10 (Inferred from "led team of 3" and presentation mentions)

Low Confidence (minimal evidence):
- Management: 3/10 (Only mentions "mentored 2 juniors" once)

Not Evaluated (no evidence):
- OT/ICS Security: N/E
- Publications: N/E
- Mobile/IoT: N/E
- Cryptography: N/E
```

### 3. Identify Candidate's Natural Profile

Based on the scores, determine:

**Dominant Domain**: What is this person's primary strength?
- Offensive (Red Team) - High scores in offensive skills, pentesting tools, exploit dev
- Defensive (Blue Team) - High scores in SOC, IR, threat hunting, forensics
- Cloud Security - High scores in cloud platforms, IaC, container security
- GRC/Compliance - High scores in governance, frameworks, auditing
- DevSecOps - High scores in CI/CD security, programming, automation
- Architecture - High scores in design, strategy, enterprise patterns
- Management/Leadership - High scores in management, soft skills, strategy

**Seniority Level**: Based on total years + score distribution
- Entry-Level: 0-2 years, scores mostly 3-5
- Junior: 1-3 years, scores 4-6
- Mid-Level: 3-5 years, scores 5-7
- Senior: 5-8 years, scores 6-8
- Principal/Expert: 8+ years, scores 7-10

**Breadth vs. Depth**:
- Specialist: Deep in 1-2 domains (scores 8-10), weaker elsewhere
- Generalist: Moderate across many domains (scores 5-7)
- Hybrid: Strong in 3-4 related domains

### 4. Identify Strengths and Weaknesses (Objective)

**Top Strengths** (Top 5 scoring dimensions):
- List the candidate's strongest areas
- Highlight exceptional skills (scores 8+)
- Note rare/valuable combinations

**Development Areas** (Bottom 5 scoring dimensions):
- List areas scoring below 5
- Identify critical gaps for their seniority level
- Note skills expected but missing

### 5. Check for Red Flags

Review `references/red_flags.md` for issues:
- Employment gaps >6 months
- Frequent job changes (3+ in 2 years)
- Certification inconsistencies (e.g., CISSP with <5 years exp)
- Vague or inflated responsibilities
- Title inflation (Senior with minimal experience)
- Keyword stuffing without depth
- Career regression without explanation

Rate each red flag: **Critical** / **High** / **Medium** / **Low**

### 6. Capture Uncategorized Information

**When you find information in the CV that doesn't fit the 24 dimensions clearly:**

Create an **"Additional Notable Information"** section with:

**Categories for uncategorized data**:
1. **Rare/Niche Certifications**: Certs not in `certifications_db.md`
2. **Emerging Technologies**: New tech not in standard categories (AI/ML security, Web3, Quantum, etc.)
3. **Unique Experience**: Specialized work that doesn't fit standard domains
4. **Languages/Frameworks**: Specific tech stacks worth noting
5. **Industry-Specific Knowledge**: Domain expertise (finance, healthcare, gaming, etc.)
6. **Awards/Recognition**: Industry awards, CVEs discovered, bug bounties
7. **Other Achievements**: Anything notable but uncategorizable

**How to handle**:
- **Don't force into wrong dimension**: If it doesn't clearly fit, don't distort scoring
- **Document separately**: Create "Additional Notable Information" section
- **Flag as potentially valuable**: Note it may be relevant for specific contexts
- **Be specific**: Include enough detail for someone to understand its value

**Example**:
```
## Additional Notable Information (Uncategorized)

### Rare Certifications
- **Certified Blockchain Security Professional (CBSP)**: Emerging certification in Web3/blockchain security
- **ISC2 HCISPP**: Healthcare-specific security cert, may indicate health sector focus

### Emerging Technologies
- **AI/ML Security**: Lists experience with "adversarial ML testing" and "model poisoning detection"
- **Quantum-Safe Cryptography**: Mentions "post-quantum crypto evaluation project"

### Unique Experience
- **CTF Competitions**: Multiple top-10 finishes in DEF CON CTF and CSAW
- **Bug Bounty**: $50K+ earnings on HackerOne, 15 critical findings
- **Military Background**: 4 years US Army Cyber Command (details classified)

### Industry Specialization
- **Gaming Security**: 3 years protecting gaming platforms from cheating/fraud
- **Fintech**: Deep knowledge of payment systems and PCI-DSS v4

### Awards & Recognition
- **CVE Discoveries**: 3 CVEs credited (CVE-2023-XXXX, CVE-2024-YYYY, CVE-2024-ZZZZ)
- **Conference Speaker**: Presented at Black Hat 2023, BSides 2024
- **SANS Cyber Defense NetWars Champion** (2023)

### Other Notable
- **Open Source**: Active contributor to Metasploit, maintains 2 security tools with 1K+ GitHub stars
- **Teaching**: Adjunct professor teaching "Web Application Security" at University X
```

**Impact on analysis**:
- Mention in "Candidate Profile" if it defines them (e.g., "Specialist with emerging tech focus")
- Note in "Suitable Roles" if it suggests niche opportunities
- Include in "Recommendations" if it suggests a unique career path

### 7. Generate Objective Recommendations

Based purely on the candidate's profile (including uncategorized info):
- **Suitable roles**: What roles would this person excel in? (reference `role_profiles.md`)
- **Certifications to pursue**: What would enhance their natural strengths?
- **Skills to develop**: What would round out their profile?
- **Career trajectory**: Where is this person heading naturally?
- **Market value**: Estimated salary range based on `market_benchmarks.json`
- **Unique positioning**: How uncategorized info creates special opportunities

## Reference Materials

### Scoring Criteria

Consult `references/scoring_rubric.md` for detailed scoring criteria across all 24 dimensions. Key scoring principles:

- **0-2**: No relevant experience
- **3-4**: Entry-level / Basic knowledge
- **5-6**: Intermediate (1-3 years hands-on)
- **7-8**: Advanced (3-5+ years, expert in subdomain)
- **9-10**: Expert (5+ years, industry-recognized)

Overall score interpretation:
- **9.0-10.0**: Exceptional (Top 5%)
- **8.0-8.9**: Excellent (Top 15%)
- **7.0-7.9**: Strong (Top 30%)
- **6.0-6.9**: Good (Above average)
- **5.0-5.9**: Average
- **4.0-4.9**: Below average
- **0-3.9**: Entry-level

### Certification Values

Reference `references/certifications_db.md` for:
- Complete certification catalog (50+ certs)
- Value scores (0-10) per certification
- Prerequisites and validity periods
- Cost and vendor information
- Target roles for each cert

**Quick certification tiers**:
- **Tier 1 (9-10)**: OSCE3, OSEP, OSWE, GXPN, GREM
- **Tier 2 (7-8)**: OSCP, CISSP, GCFA, GPEN, CRTO, Cloud certs
- **Tier 3 (5-6)**: CEH, eCPPT, CISM, CISA, BTL1
- **Tier 4 (3-4)**: Security+, CySA+, PenTest+

### Role Profiles

Consult `references/role_profiles.md` for detailed role requirements:
- Penetration Tester
- SOC Analyst (L1/L2/L3)
- Cloud Security Engineer/Architect
- Security Architect
- DevSecOps Engineer
- Incident Responder / DFIR
- CISO
- GRC Analyst
- Threat Intelligence Analyst

Each profile includes:
- Key responsibilities
- Required vs. desired skills
- Certification requirements
- Experience ranges (Junior/Mid/Senior)
- Custom scoring weight profiles

### Red Flags

Review `references/red_flags.md` when anomalies are detected. Categories:

**Critical (immediate disqualification)**:
- Fraudulent certifications
- Illegal activity references
- Major dishonesty

**High (deep investigation required)**:
- Multiple serious inconsistencies
- Skill/role mismatches
- Title inflation + vague responsibilities

**Medium (clarify in interview)**:
- Employment gaps >6 months
- Frequent job changes
- Career regressions

**Low (note but don't eliminate)**:
- Minor presentation issues
- Acceptable gaps with explanation

## Generating Outputs

### JSON Analysis Report

The complete analysis output includes:
```json
{
  "candidate_info": {
    "total_score": 7.5,
    "seniority_level": "Senior",
    "role_evaluated": "pentester"
  },
  "parsed_cv": { /* Full parsed data */ },
  "keywords": { /* Extracted keywords */ },
  "scores": {
    "total_score": 7.5,
    "dimension_scores": { /* 24 dimensions */ },
    "weights_used": { /* Role weights */ }
  },
  "summary": {
    "key_metrics": { /* Years, certs, tools count */ },
    "top_strengths": [ /* Top 3 dimensions */ ],
    "improvement_areas": [ /* Bottom 3 dimensions */ },
    "dominant_domains": [ /* Offensive/Defensive/Cloud */ ]
  },
  "recommendations": {
    "certifications_to_pursue": [ /* Suggested certs */ ],
    "areas_for_development": [ /* Weak areas */ ]
  }
}
```

### Interview Question Generation

Based on CV analysis, generate targeted interview questions:

**For detected strengths** - Validate depth:
- "You mentioned OSCP certification. Walk me through your methodology for a typical web app pentest."
- "Describe a complex cloud security architecture you designed."

**For gaps/weaknesses** - Assess willingness to learn:
- "I notice limited governance experience. How would you approach developing a security policy framework?"
- "Your CV shows primarily offensive skills. How comfortable are you with defensive operations?"

**For red flags** - Clarify concerns:
- "Can you explain the 8-month gap in 2021?"
- "I see you claim CISSP but only 3 years experience. Is this an Associate CISSP?"
- "Walk me through your role at Company X - what was the scope of your security responsibilities?"

### Presentation Format

**CRITICAL**: Use the standardized output format defined in `references/output_format.md` to enable future candidate comparisons and role matching.

**KEY REQUIREMENTS**:
1. ✅ **ALWAYS include all 24 dimensions** with scores or "N/E"
2. ✅ **ALWAYS include the ASCII radar chart** visualization
3. ✅ **ALWAYS include the JSON fingerprint** at the end
4. ✅ **ALWAYS note confidence level** for each dimension
5. ✅ **ALWAYS provide evidence** for each score

See `references/output_format.md` for the complete template.

**Quick Example** - Present analysis in this structured format:

```markdown
# CV Analysis: [Candidate Name]

## Overall Assessment
- **Score**: 7.5/10 (Strong - Top 30%)
- **Seniority**: Senior
- **Role Fit**: 78% match for Cloud Security Architect

## Key Strengths
1. **Cloud Security (8.5/10)**: Strong AWS expertise with Security Specialty cert
2. **Offensive Skills (8.0/10)**: OSCP certified, 5+ years pentesting
3. **Programming (7.5/10)**: Proficient in Python, Go, automation

## Development Areas
1. **Governance & Compliance (4.0/10)**: Limited framework experience
2. **Architecture (5.5/10)**: Needs more design authority experience

## Notable Certifications
- OSCP (Offensive Security Certified Professional)
- AWS Certified Security Specialty
- CISSP (Certified Information Systems Security Professional)

## Recommendations
- **Short-term**: Complete CCSP to strengthen cloud governance knowledge
- **Medium-term**: Lead architecture projects, obtain TOGAF or SABSA
- **Interview focus**: Validate governance understanding, assess architecture thinking

## Red Flags
� **Medium**: 6-month employment gap (2020) - clarify during interview
� **Low**: Claims CISSP with 4 years experience - verify Associate status
```

## Market Benchmarking

Use `assets/data/market_benchmarks.json` for:

**Salary estimation** based on role and score:
- Compare candidate score to market percentiles
- Adjust for regional differences
- Factor in hot certifications (OSCP, AWS Security, etc.)
- Consider skill demand index (cloud_security: very_high, devsecops: very_high)

**Example**:
Candidate with 7.5 score for "Senior Security Engineer" � $140-160K range (p50-p75)
Candidate with 8.5 score � $160-180K range (p75-p90)

**Growth areas to highlight**:
- AI/ML Security
- Zero Trust Architecture
- Container Security
- Cloud-Native Security
- Supply Chain Security
- API Security

## Best Practices

### Objectivity and Fairness

- Base evaluations solely on professional qualifications
- Avoid bias based on age, gender, nationality, or personal characteristics
- Focus on verifiable skills, certifications, and experience
- Consider context (startup vs. enterprise, regional differences)
- Give candidates benefit of doubt on minor inconsistencies

### Thoroughness

- Read complete CV, not just summary
- Cross-reference claims (e.g., CISSP requires 5 years experience)
- Look for progression and growth over time
- Consider both breadth and depth of experience
- Validate certifications are current (many expire)
- **Capture ALL notable information**: Even if it doesn't fit the 24 dimensions, document it in "Additional Notable Information"
- **Don't discard unique details**: CTF wins, bug bounties, CVEs, open source, teaching, speaking - all valuable
- **Note confidence level**: Always indicate how strong the evidence is for each score

### Context Awareness

- **Startup experience**: Broader responsibilities, potential title inflation acceptable
- **Enterprise experience**: Deeper specialization, formal processes
- **Career changers**: Lower initial experience acceptable if strong learning trajectory
- **Geographic differences**: Salary and role expectations vary by region
- **Industry**: Finance/healthcare may emphasize compliance; tech may emphasize offensive

### Communication

- Present findings clearly and concisely
- Support recommendations with specific evidence
- Quantify when possible (scores, percentiles, salary ranges)
- Distinguish facts from inferences
- Provide actionable next steps

## Limitations and Disclaimers

- **CV parsing may be imperfect**: Complex layouts, scanned PDFs, or unusual formats may not parse fully
- **Scoring is algorithmic**: Supplements but doesn't replace human judgment
- **24 dimensions don't capture everything**: Unique skills/experience documented separately in "Additional Notable Information"
- **Confidence varies by dimension**: Some scores based on strong evidence, others inferred from limited mentions
- **"N/E" doesn't mean incompetent**: It means "no evidence in CV" - absence of mention ≠ absence of skill
- **Certifications don't guarantee competence**: Validate through technical interviews
- **Market data is approximate**: Actual salaries vary widely by region, company, negotiation
- **Context matters**: Scores should be interpreted alongside full CV review and interviews
- **Bias awareness**: Regularly audit for algorithmic or systematic bias in evaluations
- **Emerging tech may be uncategorized**: New domains (AI/ML security, Web3, quantum) captured separately until frameworks evolve

## Quick Reference

**Tools to use**:
- **pdf** skill: ✅ ALWAYS use for reading PDF CVs (.pdf) - NEVER use Read tool for PDFs
- **docx** skill: ✅ ALWAYS use for reading Word documents (.docx) - NEVER use Read tool for DOCX
- **Read** tool: ✅ Only for plain text files (.txt, .md)

**References** (load as needed from `references/` directory):
- **output_format.md**: 🔴 MANDATORY - Complete output template with 24 dimensions, radar chart, JSON fingerprint
- **scoring_rubric.md**: Detailed scoring criteria for all 24 dimensions
- **certifications_db.md**: Certification values and details
- **role_profiles.md**: Target role requirements
- **red_flags.md**: Red flag categories and severity levels

**Market data**: Check `assets/data/market_benchmarks.json` for salary ranges

## Example Usage Scenarios

### Scenario 1: Basic CV Analysis
**User request**: "Analyze this CV"

**Action**:
1. Use `pdf` skill (for .pdf) or `docx` skill (for .docx) to extract CV content - NEVER use Read tool for these formats
2. Score across 24 dimensions objectively
3. Identify candidate's natural profile (Offensive/Defensive/Cloud/etc.)
4. Determine seniority level (Junior/Mid/Senior/Principal)
5. Identify top 5 strengths and bottom 5 weaknesses
6. Check for red flags in `red_flags.md`
7. Recommend suitable roles based on profile
8. Suggest certifications that align with their strengths
9. Estimate salary range using `market_benchmarks.json`

**Output example**:
```
# CV Analysis: John Doe

## Candidate Profile
- **Profile Type**: Senior-level Offensive Security Specialist
- **Seniority**: Senior (6 years experience)
- **Profile Style**: Specialist (deep in offensive, moderate elsewhere)

## Dimension Scores (Top 5 - High Confidence)
1. Offensive Skills: 8.5/10 (OSCP, OSWE, 6 years pentesting, detailed projects)
2. Programming: 7.8/10 (Python/Go fluent, 10+ tools developed, GitHub portfolio)
3. Cloud Security: 7.2/10 (AWS Security cert, 3 years cloud pentesting)
4. Certifications: 7.0/10 (OSCP, OSWE, AWS Security, Security+)
5. Technical Tools: 6.8/10 (Burp, Metasploit, Cobalt Strike, custom tools)

## Development Areas (Scored Low/Not Evaluated)
- Publications: 0/10 (None shown, expected at Senior level)
- Management: 3.0/10 (Only "mentored 2 juniors" mentioned)
- Governance: 4.0/10 (Limited framework experience shown)
- OT/ICS Security: N/E (No industrial security mentioned)
- Crisis Management: N/E (No incident leadership shown)
- Cryptography: N/E (Not mentioned)

## Scoring Confidence Summary
- **High confidence** (8 dimensions): Strong evidence from certs, projects, detailed experience
- **Medium confidence** (4 dimensions): Some evidence but limited detail
- **Low confidence** (3 dimensions): Minimal mentions, inferred from context
- **Not evaluated** (9 dimensions): No evidence in CV

## Suitable Roles
Best fit: Senior Pentester, Red Team Operator, Security Researcher
Also suitable: Application Security, Cloud Pentesting

## Market Value
Estimated: $130-150K (USD, based on Senior Offensive profile)
Market percentile: 70th percentile

## Additional Notable Information (Uncategorized)

### Bug Bounty Success
- HackerOne profile: $45K earnings, 12 critical findings
- Ranked #150 globally on platform

### CTF Competitions
- DEF CON CTF 2023: 8th place finish
- Multiple regional CTF wins

### Emerging Tech
- AI/ML Security: Built "adversarial testing framework for LLMs"
- API Security: Deep expertise in GraphQL security (not common)

### Industry Impact
- Discovered CVE-2023-12345 in popular open source tool
- Maintains security tool "XYZ" with 2.5K GitHub stars

**Note**: Bug bounty success and CTF performance suggest strong practical offensive skills beyond what certifications show. API/ML security expertise positions candidate well for emerging security domains.

## Recommendations
- Pursue OSWE to strengthen web app skills (already has OSCP)
- Consider GXPN for advanced exploitation
- Develop governance knowledge for career growth to Principal level
- Publish research/tools to build industry presence (already started with CVE and GitHub)
- **Unique opportunity**: AI/ML security is very hot - consider specializing further
```

### Scenario 2: Career Development Planning
**User request**: "What should this person work on to advance?"

**Action**:
1. Complete objective analysis
2. Identify current seniority level
3. Load expectations for their dominant domain from `role_profiles.md`
4. Compare current scores to next level threshold
5. Identify dimensions needing improvement
6. Recommend certifications and experiences
7. Provide 6-12 month development roadmap

**Output example**:
```
# Development Plan

## Current State
- Profile: Mid-Level Cloud Security
- Overall Score: 6.2/10
- Years Experience: 4

## Target: Senior Level (7.0+)

## Priority Gaps
1. **Architecture** (4.5 to 7.0)
   - Action: Lead 2-3 cloud architecture projects
   - Timeline: 6-9 months

2. **Management** (3.5 to 6.0)
   - Action: Mentor 1-2 junior engineers
   - Timeline: 3-6 months

3. **Governance** (4.0 to 6.0)
   - Action: Complete CCSP certification
   - Timeline: 3 months

## Recommended Path
1. Q1: CCSP cert + start mentoring
2. Q2-Q3: Lead architecture project
3. Q4: Second architecture project + assess progress
```

### Scenario 3: Red Flag Investigation
**User request**: "This CV looks concerning, can you check it?"

**Action**:
1. Complete standard objective analysis
2. Deep review of `red_flags.md`
3. Check timeline consistency
4. Verify certification prerequisites
5. Look for keyword stuffing
6. Check title vs. responsibility alignment
7. Analyze career progression
8. Rate red flags by severity
9. Generate clarifying questions

**Output example**:
```
# Red Flag Analysis

## HIGH SEVERITY
- Claims CISSP but only 3 years experience (requires 5 years or Associate status)
- Job titles: Junior (2020) to Senior (2021) = 12 months (too fast)

## MEDIUM SEVERITY
- Employment gap: Aug 2020 - Mar 2021 (7 months, unexplained)
- Lists 30+ tools but descriptions show limited depth

## LOW SEVERITY
- Minor formatting inconsistencies
- Some typos in technical sections

## Interview Questions
1. "Can you clarify your CISSP status? Is it Associate CISSP?"
2. "What were you doing between August 2020 and March 2021?"
3. "You progressed to Senior in 12 months - can you walk me through that?"
4. "You list Splunk - describe your most complex SIEM correlation rule"

## Recommendation
Proceed with caution. Verify certifications and probe depth during interview.
```

## Skill Maintenance

Keep the skill current by updating:

- **Monthly**: `assets/data/keywords_dictionary.json` with new tools/techniques
- **Quarterly**: `assets/data/market_benchmarks.json` with current salary data
- **Quarterly**: `references/certifications_db.md` with new certifications
- **Annually**: Scoring rubric and role profiles to reflect market evolution

Monitor cybersecurity trends and adjust skill demand index accordingly.
