# Standard Output Format for CV Analysis

**PURPOSE**: This document defines the mandatory output format for all CV analyses to enable candidate comparisons and role matching.

## Critical Requirements

✅ **ALWAYS include all 24 dimensions** with scores or "N/E"
✅ **ALWAYS include the radar chart** visualization
✅ **ALWAYS include the JSON fingerprint** at the end
✅ **ALWAYS note confidence level** for each dimension
✅ **ALWAYS provide evidence** for scores

## Complete Output Template

```markdown
# CV Analysis: [Candidate Name]

## Overall Assessment
- **Total Score**: X.X/10 (Rating - Percentile)
- **Seniority**: [Entry/Junior/Mid/Senior/Principal]
- **Candidate Type**: [Specialist/Generalist/Hybrid] - [Description]
- **Dominant Domains**: [Top 2-3 domains]

## Candidate Profile Radar (24 Dimensions)

```
         Certifications [X.X] ████████████████
    Years of Experience [X.X] ██████████████████
        Offensive Skills [X.X] ███████████████████
        Defensive Skills [X.X] ████████
   Governance & Compliance [X.X] █████████
         Cloud Security [X.X] ████████████████▌
         Technical Tools [X.X] ███████████████
  Programming & Scripting [X.X] █████████████████▌
Architecture & Design [X.X] ████████████
              Education [X.X] ██████████████▌
            Soft Skills [X.X] ███████████
              Languages [X.X] ████████████████
   DevSecOps & CI/CD [X.X] █████████████
Forensics & Malware [X.X] ─
   Cryptography Applied [X.X] ─
      OT/ICS Security [N/E] ─
   Mobile & IoT Security [N/E] ─
   Threat Intelligence [X.X] ██████████
Community Contributions [X.X] ████████████
 Publications & Research [X.X] ─
  Management & Strategy [X.X] ███████
     Crisis Management [N/E] ─
Transformation & Change [X.X] █████████
      Niche Specialties [X.X] ██████████████▌
```

**Radar Chart Rules**:
- Each █ represents 0.5 points
- N/E displayed as "─" (not scored)
- Maximum 20 blocks (10.0 points)
- Align dimension names for readability

## Complete Dimension Breakdown (24 Dimensions)

### Core Technical (1-12)

#### 1. Certifications: X.X/10
- **Evidence**: [List certs found]
- **Quality**: [Assessment of cert value]
- **Confidence**: [HIGH/MEDIUM/LOW]

#### 2. Years of Experience: X.X/10
- **Total**: X years in cybersecurity
- **Confidence**: [HIGH/MEDIUM/LOW]

#### 3. Offensive Skills: X.X/10
- **Evidence**: [Certs, projects, tools, years]
- **Details**: [Specific pentesting/red team experience]
- **Confidence**: [HIGH/MEDIUM/LOW]

#### 4. Defensive Skills: X.X/10
- **Evidence**: [SOC, IR, threat hunting details]
- **Tools**: [SIEM, EDR, etc.]
- **Confidence**: [HIGH/MEDIUM/LOW]

#### 5. Governance & Compliance: X.X/10
- **Evidence**: [Frameworks, audits, policies]
- **Standards**: [ISO 27001, SOC 2, NIST, etc.]
- **Confidence**: [HIGH/MEDIUM/LOW]

#### 6. Cloud Security: X.X/10
- **Evidence**: [Certs, platforms, years]
- **Platforms**: AWS [score], Azure [score], GCP [score]
- **Confidence**: [HIGH/MEDIUM/LOW]

#### 7. Technical Tools: X.X/10
- **Evidence**: [Number of tools, depth of use]
- **Categories**: Offensive [score], Defensive [score], Cloud [score]
- **Confidence**: [HIGH/MEDIUM/LOW]

#### 8. Programming & Scripting: X.X/10
- **Evidence**: [Languages, projects, code examples]
- **Languages**: [List with proficiency levels]
- **Confidence**: [HIGH/MEDIUM/LOW]

#### 9. Architecture & Secure Design: X.X/10
- **Evidence**: [Design projects, patterns, leadership]
- **Scope**: [Enterprise/Application/Cloud architecture]
- **Confidence**: [HIGH/MEDIUM/LOW]

#### 10. Education: X.X/10
- **Degrees**: [List degrees]
- **Relevant Training**: [Courses, bootcamps]
- **Confidence**: HIGH

#### 11. Soft Skills: X.X/10
- **Evidence**: [Leadership, communication, collaboration examples]
- **Assessment**: [How inferred from CV]
- **Confidence**: [HIGH/MEDIUM/LOW]

#### 12. Languages: X.X/10
- **Languages**: [List with proficiency]
- **Technical Writing**: [Evidence of written communication]
- **Confidence**: [HIGH/MEDIUM/LOW]

### Specialized (13-24)

#### 13. DevSecOps & CI/CD Security: X.X/10 or N/E
- **Evidence**: [If applicable]
- **Confidence**: [If scored]

#### 14. Forensics & Malware Analysis: X.X/10 or N/E
- **Evidence**: [If applicable]
- **Confidence**: [If scored]

#### 15. Cryptography Applied: X.X/10 or N/E
- **Evidence**: [If applicable]
- **Confidence**: [If scored]

#### 16. OT/ICS Security: X.X/10 or N/E
- **Evidence**: [If applicable]
- **Confidence**: [If scored]

#### 17. Mobile & IoT Security: X.X/10 or N/E
- **Evidence**: [If applicable]
- **Confidence**: [If scored]

#### 18. Threat Intelligence: X.X/10 or N/E
- **Evidence**: [If applicable]
- **Confidence**: [If scored]

#### 19. Community Contributions: X.X/10 or N/E
- **Evidence**: [Open source, forums, blogging, speaking]
- **Confidence**: [If scored]

#### 20. Publications & Research: X.X/10 or N/E
- **Evidence**: [Papers, talks, research, CVEs]
- **Confidence**: [If scored]

#### 21. Management & Strategy: X.X/10 or N/E
- **Evidence**: [Team lead, management, strategy projects]
- **Confidence**: [If scored]

#### 22. Crisis Management: X.X/10 or N/E
- **Evidence**: [Incident response leadership, breach handling]
- **Confidence**: [If scored]

#### 23. Transformation & Change: X.X/10 or N/E
- **Evidence**: [Large initiatives, cultural change, program leadership]
- **Confidence**: [If scored]

#### 24. Niche Specialties: X.X/10 or N/E
- **Evidence**: [Unique expertise not covered above]
- **Details**: [Specific niche areas]
- **Confidence**: [If scored]

## Scoring Confidence Summary

- **High Confidence** (X dimensions): [List - strong evidence from certs, detailed projects, clear experience]
- **Medium Confidence** (X dimensions): [List - some evidence but limited detail or inferred]
- **Low Confidence** (X dimensions): [List - minimal mentions, weak evidence]
- **Not Evaluated** (X dimensions): [List - no evidence in CV]

## Top 5 Strengths

1. **[Dimension] (X.X/10)**: [Brief explanation with evidence]
2. **[Dimension] (X.X/10)**: [Brief explanation with evidence]
3. **[Dimension] (X.X/10)**: [Brief explanation with evidence]
4. **[Dimension] (X.X/10)**: [Brief explanation with evidence]
5. **[Dimension] (X.X/10)**: [Brief explanation with evidence]

## Bottom 5 Scored Dimensions (Excluding N/E)

1. **[Dimension] (X.X/10)**: [Brief explanation]
2. **[Dimension] (X.X/10)**: [Brief explanation]
3. **[Dimension] (X.X/10)**: [Brief explanation]
4. **[Dimension] (X.X/10)**: [Brief explanation]
5. **[Dimension] (X.X/10)**: [Brief explanation]

## Notable Certifications

- **[Cert Name]** - Value: X/10, [Status: active/expired], [Additional context]
- **[Cert Name]** - Value: X/10, [Status: active/expired], [Additional context]

## Additional Notable Information (Uncategorized)

### Rare/Emerging Certifications
[If applicable]

### Emerging Technologies
[AI/ML security, Web3, quantum, etc.]

### Unique Experience
[CTFs, bug bounties, military, unique projects]

### Industry Specialization
[Finance, healthcare, gaming, etc.]

### Awards & Recognition
[CVEs, conference speaking, awards]

### Other Notable
[Open source, teaching, book authoring]

## Red Flags

**[SEVERITY LEVEL]**: [Description]
- **Critical**: [If any - immediate concern]
- **High**: [If any - requires deep investigation]
- **Medium**: [If any - clarify in interview]
- **Low**: [If any - minor note]
- **None Detected**: [If clean]

## Suitable Roles (Based on Profile)

- **Best Fit**: [Role 1], [Role 2], [Role 3]
- **Also Suitable**: [Role 4], [Role 5]
- **Growth Path**: [Current] → [Next level] → [Long-term] ([gaps to address])

## Recommendations

### Certifications to Pursue
1. **[Cert Name]**: [Why - aligns with strengths/fills gap]
2. **[Cert Name]**: [Why]

### Skills to Develop
1. **[Dimension/Area]**: [Why important for career growth]
2. **[Dimension/Area]**: [Why]

### Career Trajectory
[Natural direction based on profile + strengths]

## Market Value Estimation

- **Estimated Salary Range**: $XXK-$XXXK [Currency] ([Seniority] level, [Region])
- **Market Percentile**: Xth percentile for [dominant domain]
- **Hot Skills Modifiers**: [Skill] (+X%), [Skill] (+Y%)
- **Regional Adjustments**: [If applicable]

## Candidate Fingerprint (For Comparisons)

```json
{
  "candidate_id": "[name_year]",
  "analysis_date": "YYYY-MM-DD",
  "total_score": X.X,
  "seniority": "[Level]",
  "years_experience": X,
  "dominant_domains": ["Domain1", "Domain2", "Domain3"],
  "profile_type": "Specialist|Generalist|Hybrid",
  "top_dimension": "[Dimension] (X.X)",
  "unique_strengths": ["Strength1", "Strength2", "Strength3"],
  "critical_gaps": ["Gap1", "Gap2", "Gap3"],
  "dimension_scores": {
    "certifications": X.X,
    "years_of_experience": X.X,
    "offensive_skills": X.X,
    "defensive_skills": X.X,
    "governance_compliance": X.X,
    "cloud_security": X.X,
    "technical_tools": X.X,
    "programming_scripting": X.X,
    "architecture_design": X.X,
    "education": X.X,
    "soft_skills": X.X,
    "languages": X.X,
    "devsecops": X.X,
    "forensics_malware": X.X,
    "cryptography": X.X,
    "ot_ics": X.X,
    "mobile_iot": X.X,
    "threat_intelligence": X.X,
    "community": X.X,
    "publications": X.X,
    "management": X.X,
    "crisis_management": X.X,
    "transformation": X.X,
    "niche_specialties": X.X
  },
  "notable_certs": ["Cert1", "Cert2"],
  "red_flags": {
    "critical": [],
    "high": [],
    "medium": [],
    "low": []
  },
  "best_fit_roles": ["Role1", "Role2"],
  "salary_estimate": {
    "min": XXX000,
    "max": XXX000,
    "currency": "USD",
    "percentile": XX
  }
}
```

---

## Usage Notes

### Why This Format?

This standardized format enables:

1. **Candidate Comparison**: Side-by-side analysis of multiple candidates
2. **Role Matching**: Automated matching against job requirements (future skill)
3. **Gap Analysis**: Clear identification of strengths vs. role needs
4. **Portfolio Management**: Track candidates over time
5. **Data-Driven Decisions**: JSON export for programmatic analysis

### For Future Candidate Comparison Skill

The JSON fingerprint can be used by a future "candidate-matcher" skill to:
- Load multiple candidate fingerprints
- Compare against role requirement profiles
- Generate ranked candidate lists
- Identify best-fit candidates per dimension
- Highlight unique candidate differentiators

### Consistency Checklist

Before finalizing analysis, verify:

- [ ] All 24 dimensions have scores or "N/E"
- [ ] Radar chart is properly formatted
- [ ] Evidence provided for each scored dimension
- [ ] Confidence levels noted
- [ ] JSON fingerprint is complete and valid
- [ ] Salary estimate included
- [ ] Red flags section completed (even if "None")
- [ ] Suitable roles identified
- [ ] Additional notable information captured

### Example Dimension Score Format

**GOOD**:
```
#### 3. Offensive Skills: 8.5/10
- **Evidence**: OSCP (2021), OSWE (2023), 6 years pentesting, 15+ detailed projects
- **Details**: Web app pentesting (expert), network pentesting (advanced), API security (strong)
- **Tools**: Burp Suite Pro, Metasploit, Cobalt Strike, custom Python exploits
- **Confidence**: HIGH
```

**BAD**:
```
Offensive Skills: 8.5 - Pretty good at pentesting
```

Always provide context, evidence, and confidence.
