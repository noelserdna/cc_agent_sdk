# Scoring Rubric - Cybersecurity CV Analysis

Detailed scoring criteria for all 24 evaluation dimensions.

## Core Technical Competencies (1-12)

### 1. Certifications (0-10)

**0-2: No relevant certifications**
- No cybersecurity certifications
- Only general IT certifications (A+, basic networking)

**3-4: Entry-level certifications**
- CompTIA Security+
- CompTIA Network+
- CompTIA CySA+

**5-6: Intermediate certifications**
- CEH (Certified Ethical Hacker)
- ECSA, CHFI
- eJPT, eCPPT
- GIAC GSEC

**7-8: Advanced certifications**
- OSCP (Offensive Security Certified Professional)
- CISSP (Certified Information Systems Security Professional)
- CISM, CISA
- GCIH, GCIA, GPEN
- AWS/Azure/GCP Security Specialty

**9-10: Expert-level certifications**
- OSCE3, OSEP, OSWE
- Multiple GIAC Expert certifications
- Multiple advanced certifications across domains
- Rare/difficult certifications (GXPN, GREM)

### 2. Years of Experience (0-10)

**0-2: 0-1 years**
- Entry-level, minimal experience
- Recent graduate or career changer

**3-4: 1-2 years**
- Junior level
- Basic hands-on experience

**5-6: 3-4 years**
- Mid-level emerging
- Solid foundation

**7-8: 5-7 years**
- Senior-level experience
- Deep domain knowledge

**9-10: 8+ years**
- Expert/Principal level
- Extensive experience across multiple domains

### 3. Offensive Skills (Red Team) (0-10)

**0-2: No offensive experience**
- No penetration testing or red team work

**3-4: Basic offensive knowledge**
- Completed training courses
- Lab environments only
- Basic vulnerability scanning

**5-6: Intermediate offensive skills**
- 1-2 years pentesting
- Web/network testing experience
- Basic exploit usage

**7-8: Advanced offensive skills**
- 3+ years pentesting
- Exploit development experience
- Red team operations
- Multiple domains (web, network, mobile)

**9-10: Expert offensive skills**
- 5+ years advanced red team work
- Custom exploit development
- 0-day research
- Advanced evasion techniques
- Published vulnerabilities

### 4. Defensive Skills (Blue Team) (0-10)

**0-2: No defensive experience**
- No SOC, IR, or monitoring experience

**3-4: Basic defensive knowledge**
- Entry-level SOC analyst
- Log review basics
- Alert triage

**5-6: Intermediate defensive skills**
- 1-2 years SOC experience
- Incident response participation
- SIEM rule creation
- Basic threat hunting

**7-8: Advanced defensive skills**
- 3+ years SOC/IR experience
- Lead incident responder
- Threat hunting programs
- Detection engineering
- Forensics capabilities

**9-10: Expert defensive skills**
- 5+ years advanced blue team work
- SOC program development
- Advanced forensics/malware analysis
- Threat hunting at scale
- Detection strategy leadership

### 5. Governance & Compliance (0-10)

**0-2: No governance experience**
- No policy, compliance, or risk work

**3-4: Basic governance knowledge**
- Participated in audits
- Policy awareness
- Basic compliance understanding

**5-6: Intermediate governance**
- Risk assessments conducted
- Policy development participation
- Compliance project involvement
- Framework awareness (ISO, NIST)

**7-8: Advanced governance**
- Risk management program ownership
- Audit leadership
- Multiple framework implementations
- Regulatory compliance experience

**9-10: Expert governance**
- CISO-level governance experience
- Board-level risk reporting
- Multiple compliance programs led
- Framework customization and strategy

### 6. Cloud Security (0-10)

**0-2: No cloud experience**
- Traditional on-prem only

**3-4: Basic cloud knowledge**
- Basic AWS/Azure/GCP usage
- Cloud fundamentals understanding

**5-6: Intermediate cloud security**
- 1-2 years cloud security work
- IAM configuration
- Basic security controls
- Single cloud platform

**7-8: Advanced cloud security**
- 3+ years cloud security
- Multi-cloud experience
- Security architecture in cloud
- IaC security
- Container security

**9-10: Expert cloud security**
- 5+ years cloud security leadership
- Cloud security program design
- Advanced services (GuardDuty, Sentinel, etc.)
- Multi-cloud strategy
- Cloud-native security

### 7. Technical Tools (0-10)

Scored based on breadth and depth of tool experience:
- **0-2**: Minimal tool knowledge
- **3-4**: 3-5 basic tools
- **5-6**: 5-10 tools, some advanced
- **7-8**: 10-15 tools, multiple categories
- **9-10**: 15+ tools, expert-level usage, tool development

### 8. Programming & Scripting (0-10)

**0-2: No programming**
- Cannot script or code

**3-4: Basic scripting**
- Basic Bash or PowerShell
- Simple automation scripts

**5-6: Intermediate programming**
- Python proficiency
- Multiple scripting languages
- Tool modification

**7-8: Advanced programming**
- Multiple compiled languages
- Tool development
- API integration
- Complex automation

**9-10: Expert programming**
- Advanced development skills
- Published security tools
- Exploit development
- Low-level programming (C/C++, Assembly)

### 9. Architecture & Secure Design (0-10)

**0-2: No architecture experience**
- Implementation only

**3-4: Basic architecture understanding**
- Aware of security patterns
- Understands basic designs

**5-6: Intermediate architecture**
- Participates in design reviews
- Network segmentation experience
- Security by design awareness

**7-8: Advanced architecture**
- Leads security architecture
- Zero Trust implementations
- Threat modeling expertise
- Design authority

**9-10: Expert architecture**
- Enterprise architecture leadership
- Novel architecture patterns
- Published architecture work
- Industry recognition

### 10. Education (0-10)

**0-2: No formal education**
- High school only

**3-4: Some college/certifications**
- Associates degree or equivalent training

**5-6: Bachelor's degree**
- BS/BA in relevant field
- Cybersecurity bootcamp

**7-8: Advanced degree**
- Master's in cybersecurity/CS
- Specialized training programs

**9-10: Terminal degree/exceptional**
- PhD
- Multiple advanced degrees
- Published research

### 11. Soft Skills (0-10)

Evaluated based on CV evidence:
- **0-2**: No evidence
- **3-4**: Basic communication
- **5-6**: Team collaboration, presentations
- **7-8**: Leadership, stakeholder management
- **9-10**: Executive communication, thought leadership

### 12. Languages (0-10)

**0-4**: Native language only
**5-6**: Professional English (technical reading/writing)
**7-8**: Fluent English + technical writing
**9-10**: Multiple languages, international work

## Specialized Competencies (13-24)

### 13-24: Specialized Domains

Each specialized domain scored 0-10 based on:
- **0-2**: No experience
- **3-4**: Basic awareness/training
- **5-6**: 1-2 years hands-on experience
- **7-8**: 3+ years, expert in subdomain
- **9-10**: 5+ years, industry-recognized expert

Domains: DevSecOps, Forensics, Cryptography, OT/ICS, Mobile/IoT, Threat Intelligence, Community Contributions, Publications, Management, Crisis Management, Transformation, Niche Specialties.

## Score Interpretation

### Overall Score Ranges

- **9.0-10.0**: Exceptional - Top 5% of market
- **8.0-8.9**: Excellent - Top 15% of market
- **7.0-7.9**: Strong - Top 30% of market
- **6.0-6.9**: Good - Above average
- **5.0-5.9**: Average - Meets baseline
- **4.0-4.9**: Below average - Development needed
- **0-3.9**: Entry-level - Significant gaps

## Seniority Level Determination

Combine overall score with years of experience:

**Entry-Level**: 0-2 years, score 4.0-5.5
**Junior**: 1-3 years, score 5.0-6.5
**Mid-Level**: 3-5 years, score 6.0-7.5
**Senior**: 5-8 years, score 7.0-8.5
**Principal/Expert**: 8+ years, score 8.0+
