# Red Flags in Cybersecurity CVs

Common warning signs and how to evaluate them during CV screening.

## Experience-Related Red Flags

### 1. Frequent Job Changes (Job Hopping)
**Pattern**: Multiple jobs lasting <1 year without clear reason

**Severity**: Medium-High

**What to look for**:
- 3+ jobs in 2 years
- Pattern of short tenures
- No contract/consulting indication

**How to evaluate**:
- Ask about reasons during interview
- Look for contract roles (acceptable)
- Startup failures (acceptable)
- Layoffs (acceptable)
- Pattern vs. isolated incidents

**Red flag if**: Consistent pattern without explanation

### 2. Unexplained Employment Gaps
**Pattern**: Gaps >6 months between positions

**Severity**: Medium

**What to look for**:
- Gaps of 6+ months
- Multiple gaps
- Recent gaps more concerning

**Acceptable explanations**:
- Sabbatical
- Education/training
- Family reasons
- Health issues
- Job market conditions (2008, 2020, etc.)

**Action**: Ask for clarification

### 3. Title Inflation
**Pattern**: Titles don't match experience level

**Severity**: Medium-High

**Examples**:
- "Senior Security Engineer" with 1 year experience
- "Security Architect" with no architecture work
- "CISO" at tiny company
- "Lead" with no team

**How to evaluate**:
- Compare title to actual responsibilities
- Company size matters (startups often inflate titles)
- Look at scope of work
- Verify during reference checks

### 4. Vague or Inflated Responsibilities
**Pattern**: Buzzword-heavy descriptions without specifics

**Severity**: High

**Warning signs**:
- "Responsible for all security"
- "Led enterprise security" at 50-person company
- Generic descriptions
- No specific achievements or metrics
- Claims of solo implementation of enterprise tools

**What to verify**:
- Ask for specific examples
- Technical deep-dive questions
- Project details

### 5. Regression in Career Progression
**Pattern**: Moving to lower-level roles

**Severity**: Low-Medium

**Example**: Senior Engineer → Junior Analyst

**Acceptable reasons**:
- Career change/pivot
- Relocation constraints
- Company size/prestige trade-off
- Remote work preference
- Burnout recovery

**Concern if**: No explanation + multiple regressions

## Certification-Related Red Flags

### 6. Claimed Certifications Not Possible
**Pattern**: Certification requirements not met

**Severity**: High (potential fraud)

**Examples**:
- CISSP with <5 years experience (should be Associate)
- Multiple OSCP variants claimed as separate certs
- Cert claimed before it existed
- Impossible timeline (multiple difficult certs in months)

**Action**:
- Verify with issuing body
- Request certification number
- Check dates carefully

### 7. Expired Certifications Presented as Current
**Severity**: Medium

**What to check**:
- CEH, Security+, CySA+ expire in 3 years
- GIAC certs expire in 4 years
- Some certs are lifetime (OSCP, OSWE, etc.)

**Action**: Ask for current status

### 8. Certification Mills or Fake Certs
**Severity**: High

**Warning signs**:
- Unknown certification body
- "Certified Security Expert" from unknown org
- Udemy/Coursera completion certificates presented as certs
- Pay-for-cert schemes

### 9. Over-reliance on Certifications
**Severity**: Low-Medium

**Pattern**: Many certs but minimal practical experience

**Example**: 10 certifications but 2 years experience, all training roles

**Concern**: "Paper tiger" - theoretical knowledge without practical application

## Technical Red Flags

### 10. Keyword Stuffing
**Pattern**: Excessive listing of technologies without context

**Severity**: High

**Example**:
```
Skills: AWS, Azure, GCP, Splunk, QRadar, ArcSight, Burp Suite,
Metasploit, Nmap, Wireshark, Python, Java, C++, Go, Rust, Ruby,
PHP, JavaScript, Docker, Kubernetes, Terraform, Ansible, IDS, IPS,
SIEM, EDR, XDR, SOAR, Firewall, WAF, DLP, IAM, PAM, CASB...
```

**What to check**:
- No context or experience level
- Unrealistic breadth for experience level
- No indication of depth

**Action**: Technical deep-dive on claimed skills

### 11. Lack of Progression in Skills
**Severity**: Medium

**Pattern**: Same skills listed across 5+ years

**Concern**: Not keeping up with evolving field

**Example**: 7 years experience, only mentions skills from 2015

### 12. Mismatch Between Role and Skills
**Severity**: High

**Examples**:
- "Red Team Lead" but no offensive tools listed
- "Cloud Security Architect" with no cloud experience
- "SOC Manager" with no SIEM experience

### 13. Grammatical/Technical Errors
**Severity**: Varies

**Examples**:
- "Performed SQL injection on production" (red flag!)
- "Hacked into systems" (poor phrasing)
- Basic technical term errors
- Poor English (unless non-native, then minor)

## Behavioral Red Flags

### 14. Lack of Growth/Learning
**Severity**: Medium

**Pattern**:
- No new certifications
- No conferences/training
- No community involvement
- Stagnant skill set

**Note**: Especially concerning for 5+ year careers

### 15. No Measurable Achievements
**Severity**: Medium

**Pattern**: Only lists responsibilities, no accomplishments

**Example**:
- "Responsible for security monitoring" (weak)
- vs. "Reduced MTTD by 40% through SIEM optimization" (strong)

### 16. Overemphasis on Education (for experienced candidates)
**Severity**: Low

**Pattern**: Senior professionals leading with education

**Note**: Education important for entry-level, less so for 5+ years

### 17. Unprofessional Presentation
**Severity**: Low-Medium

**Examples**:
- Photo on CV (red flag in US, normal in some countries)
- Unprofessional email (sexybeast@hotmail.com)
- Poor formatting
- Typos and errors
- Personal info overshare

## Specific Cybersecurity Red Flags

### 18. Grey Hat/Illegal Activity References
**Severity**: Critical

**Examples**:
- "Unauthorized access to systems"
- Grey hat hacking without authorization
- Illegal activities
- Hacking without permission

**Action**: Immediate disqualification unless authorized (bug bounty, research)

### 19. Bug Bounty as Only Experience
**Severity**: Low-Medium for entry-level, High for senior roles

**Pattern**: Claims extensive experience but only bug bounty work

**Concern**:
- Lack of enterprise environment understanding
- No team collaboration
- Cherry-picking vs. comprehensive security

**Valid for**: Entry-level, when supplemented with formal experience

### 20. Clearance/Classification Vagueness
**Severity**: Medium

**Pattern**: Vague references to classified work

**Valid**: "Security Clearance (cannot discuss details)"
**Red flag**: Using classified work to avoid technical questions

## How to Handle Red Flags

### Severity Levels

**Critical (Immediate DQ)**:
- Fraudulent certifications
- Illegal activity
- Major dishonesty

**High (Deep investigation required)**:
- Multiple serious inconsistencies
- Skill/role mismatches
- Title inflation + vague responsibilities

**Medium (Clarify in interview)**:
- Employment gaps
- Career changes
- Some inconsistencies

**Low (Note but don't eliminate)**:
- Minor presentation issues
- Acceptable gaps
- Explainable anomalies

### Interview Questions for Red Flags

**For job hopping**:
"I noticed several role changes. Can you walk me through your career decisions?"

**For gaps**:
"I see a gap in 2020-2021. What were you doing during that time?"

**For vague responsibilities**:
"Can you give me a specific example of [claimed skill/responsibility]?"

**For certification concerns**:
"Can you describe the process you went through for [certification]?"

**For technical claims**:
"Walk me through how you [specific technical accomplishment]."

## Positive Signals (Anti-Red Flags)

Things that offset red flags:

✅ Strong recommendations
✅ Verifiable achievements
✅ GitHub/portfolio with quality work
✅ Speaking engagements
✅ Published research
✅ Long tenures at reputable companies
✅ Progressive responsibility increases
✅ Community contributions
✅ Continuous learning evidence
✅ Specific, measurable accomplishments
✅ Cultural fit indicators
✅ Strong technical depth in interviews

## Final Note

**Context matters**: Always consider the complete picture. One red flag doesn't eliminate a candidate, but multiple red flags create a pattern. The goal is to identify issues early while remaining fair and objective.

**Regional differences**: Some "red flags" are cultural (photos on CVs, job hopping norms, title inflation in startups).

**Verification is key**: When in doubt, verify during interviews and reference checks.
