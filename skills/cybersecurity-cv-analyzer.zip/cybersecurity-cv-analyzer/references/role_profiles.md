# Cybersecurity Role Profiles

Detailed profiles of common cybersecurity roles with requirements and scoring weights.

## Penetration Tester / Ethical Hacker

### Overview
Tests security of systems, networks, and applications by simulating attacks.

### Key Responsibilities
- Conduct penetration tests on web apps, networks, APIs
- Identify and exploit vulnerabilities
- Document findings and provide remediation guidance
- Stay current with attack techniques and tools

### Required Skills (Minimum)
- Strong networking fundamentals
- Linux and Windows OS knowledge
- Web application architecture
- Basic scripting (Python, Bash)
- Understanding of common vulnerabilities (OWASP, CVEs)

### Desired Skills
- Exploit development
- Active Directory attacks
- Mobile/thick client testing
- Cloud pentesting
- Red team operations

### Certifications
- **Minimum**: Security+, CEH, or eJPT
- **Preferred**: OSCP
- **Advanced**: OSEP, OSWE, GPEN

### Experience Range
- Junior: 0-2 years
- Mid: 2-5 years
- Senior: 5+ years

### Scoring Weight Profile
- Offensive Skills: 25%
- Certifications: 15%
- Programming: 12%
- Technical Tools: 10%
- Years Experience: 8%
- Cloud Security: 8%
- Other dimensions: 22%

---

## SOC Analyst (Security Operations Center)

### Overview
Monitors security events, investigates alerts, responds to incidents.

### Levels

#### L1 (Tier 1) - Alert Triage
- Monitor SIEM dashboards
- Triage security alerts
- Escalate true positives
- Basic log analysis
- **Experience**: 0-2 years
- **Certifications**: Security+, CySA+

#### L2 (Tier 2) - Investigation
- Deep dive investigations
- Threat hunting
- Incident response coordination
- SIEM rule tuning
- **Experience**: 2-5 years
- **Certifications**: CySA+, BTL1, GCIH

#### L3 (Tier 3) - Advanced Analysis
- Complex threat analysis
- Malware reverse engineering
- Threat intelligence integration
- Detection engineering
- **Experience**: 5+ years
- **Certifications**: GCFA, GNFA, GCIA

### Key Skills
- SIEM platforms (Splunk, QRadar, Sentinel)
- Log analysis
- Network traffic analysis
- Incident response procedures
- Threat intelligence

### Scoring Weight Profile
- Defensive Skills: 25%
- Technical Tools: 15%
- Certifications: 12%
- Threat Intelligence: 10%
- Years Experience: 8%
- Forensics: 8%
- Other: 22%

---

## Cloud Security Engineer/Architect

### Overview
Designs and implements security controls for cloud environments.

### Key Responsibilities
- Design secure cloud architectures
- Implement IAM, network security, encryption
- Security automation and IaC
- Cloud security monitoring
- Compliance and governance

### Required Skills
- Deep knowledge of cloud platforms (AWS/Azure/GCP)
- Infrastructure as Code (Terraform, CloudFormation)
- Container and Kubernetes security
- DevSecOps practices
- Security automation

### Desired Skills
- Multi-cloud experience
- CSPM/CWPP tools
- Serverless security
- CI/CD security
- Python/Go for automation

### Certifications
- **Minimum**: AWS/Azure/GCP Security certification
- **Preferred**: CCSP, CKS (Kubernetes)
- **Bonus**: OSCP (for security mindset)

### Experience Range
- Junior: 1-3 years cloud + security
- Mid: 3-5 years
- Senior: 5-8 years
- Architect: 8+ years

### Scoring Weight Profile
- Cloud Security: 25%
- Architecture: 20%
- DevSecOps: 12%
- Programming: 10%
- Certifications: 10%
- Technical Tools: 8%
- Other: 15%

---

## Security Architect

### Overview
Designs enterprise security solutions and strategies.

### Key Responsibilities
- Design security architectures
- Threat modeling
- Security standards and frameworks
- Technology selection
- Security roadmap development

### Required Skills
- Enterprise architecture experience
- Security design patterns
- Multiple technology domains
- Risk management
- Technical leadership

### Desired Skills
- Zero Trust architecture
- SABSA or TOGAF
- Cloud architecture
- M&A security integration
- Emerging technologies

### Certifications
- **Minimum**: CISSP or equivalent
- **Preferred**: SABSA, TOGAF, Cloud certs
- **Bonus**: Technical certs (OSCP, AWS)

### Experience
- Typically 8+ years total, 5+ in security

### Scoring Weight Profile
- Architecture: 25%
- Governance & Compliance: 15%
- Cloud Security: 12%
- Years Experience: 12%
- Technical Tools: 10%
- Certifications: 10%
- Other: 16%

---

## DevSecOps Engineer

### Overview
Integrates security into CI/CD pipelines and development workflows.

### Key Responsibilities
- SAST/DAST implementation
- Container security
- CI/CD pipeline security
- Security automation
- Developer security training

### Required Skills
- CI/CD platforms (Jenkins, GitLab, GitHub Actions)
- Container/Kubernetes
- SAST/DAST/SCA tools
- Scripting/programming (Python, Go)
- Cloud platforms

### Desired Skills
- Security tool development
- Infrastructure as Code security
- Secrets management
- API security
- Threat modeling

### Certifications
- **Preferred**: OSCP, AWS Security, CKS
- **Bonus**: Developer certs, cloud certs

### Experience
- 3+ years DevOps/Development + Security

### Scoring Weight Profile
- DevSecOps: 25%
- Programming: 20%
- Cloud Security: 15%
- Technical Tools: 12%
- Architecture: 10%
- Other: 18%

---

## Incident Responder / DFIR

### Overview
Responds to security incidents, conducts forensics investigations.

### Key Responsibilities
- Lead incident response
- Digital forensics analysis
- Malware analysis
- Evidence collection and preservation
- Post-incident reporting

### Required Skills
- Incident response methodology
- Forensics tools (EnCase, FTK, Volatility)
- Memory and disk forensics
- Windows/Linux internals
- Log analysis

### Desired Skills
- Malware reverse engineering
- Threat hunting
- SOAR automation
- Cloud forensics
- Mobile forensics

### Certifications
- **Minimum**: GCIH, BTL1
- **Preferred**: GCFA, GNFA, GREM
- **Bonus**: OSCP, CHFI

### Experience
- Junior: 1-3 years
- Senior: 5+ years

### Scoring Weight Profile
- Defensive Skills: 25%
- Forensics: 20%
- Incident Response: 15%
- Technical Tools: 12%
- Threat Intelligence: 10%
- Other: 18%

---

## CISO (Chief Information Security Officer)

### Overview
Executive responsible for organization's security strategy and program.

### Key Responsibilities
- Security strategy and vision
- Risk management
- Board reporting
- Budget management
- Team leadership
- Regulatory compliance

### Required Skills
- Security program management
- Risk management frameworks
- Executive communication
- Budget and vendor management
- Regulatory knowledge

### Desired Skills
- Technical depth
- Industry knowledge
- M&A experience
- Crisis management
- Transformation leadership

### Certifications
- **Minimum**: CISSP, CISM
- **Preferred**: CISA, CRISC
- **Bonus**: Technical certs demonstrate depth

### Experience
- Typically 12+ years, with 5+ in leadership

### Scoring Weight Profile
- Management: 20%
- Governance & Compliance: 18%
- Years Experience: 15%
- Soft Skills: 12%
- Certifications: 10%
- Risk Management: 10%
- Other: 15%

---

## GRC Analyst (Governance, Risk, Compliance)

### Overview
Manages compliance programs, risk assessments, and security policies.

### Key Responsibilities
- Compliance management (PCI, HIPAA, SOC2, etc.)
- Risk assessments
- Policy development
- Audit coordination
- Control testing

### Required Skills
- Regulatory frameworks
- Risk assessment methodologies
- Audit processes
- GRC tools
- Policy writing

### Certifications
- **Preferred**: CISA, CRISC, ISO 27001
- **Bonus**: CISSP, domain-specific (PCI-QSA, etc.)

### Scoring Weight Profile
- Governance & Compliance: 30%
- Risk Management: 20%
- Certifications: 12%
- Soft Skills: 10%
- Other: 28%

---

## Threat Intelligence Analyst

### Overview
Collects, analyzes, and disseminates threat intelligence.

### Key Responsibilities
- Threat research and analysis
- Intelligence report writing
- IOC identification
- Threat actor tracking
- Intelligence platform management

### Required Skills
- OSINT techniques
- Threat landscape knowledge
- Analytical thinking
- Report writing
- CTI platforms

### Scoring Weight Profile
- Threat Intelligence: 30%
- Defensive Skills: 15%
- Soft Skills: 12%
- Technical Tools: 10%
- Other: 33%
