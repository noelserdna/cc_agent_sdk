# Cybersecurity Certifications Database

Comprehensive catalog of cybersecurity certifications with values and details.

## Entry-Level Certifications

### CompTIA Security+ (Sec+)
- **Value**: 3/10
- **Vendor**: CompTIA
- **Prerequisites**: None (A+ and Network+ recommended)
- **Validity**: 3 years
- **Cost**: ~$400
- **Focus**: Security fundamentals, general knowledge
- **Target Roles**: Entry-level security analyst, IT security

### CompTIA CySA+ (Cybersecurity Analyst)
- **Value**: 4/10
- **Vendor**: CompTIA
- **Prerequisites**: Security+ or equivalent experience
- **Validity**: 3 years
- **Cost**: ~$400
- **Focus**: Threat detection, analysis, response
- **Target Roles**: SOC Analyst, Security Analyst

### CompTIA PenTest+
- **Value**: 4/10
- **Vendor**: CompTIA
- **Prerequisites**: Security+ or equivalent
- **Validity**: 3 years
- **Cost**: ~$400
- **Focus**: Penetration testing basics
- **Target Roles**: Junior Pentester

## Intermediate Offensive Certifications

### CEH (Certified Ethical Hacker)
- **Value**: 5/10
- **Vendor**: EC-Council
- **Prerequisites**: None (2 years experience recommended)
- **Validity**: 3 years
- **Cost**: ~$1,200
- **Focus**: Ethical hacking techniques
- **Target Roles**: Pentester, Security Consultant
- **Notes**: Well-known but criticized for being too theoretical

### eCPPT (Certified Professional Penetration Tester)
- **Value**: 6/10
- **Vendor**: eLearnSecurity/INE
- **Prerequisites**: None
- **Validity**: 3 years
- **Cost**: ~$400
- **Focus**: Practical penetration testing
- **Target Roles**: Pentester
- **Notes**: Hands-on practical exam

### PNPT (Practical Network Penetration Tester)
- **Value**: 7/10
- **Vendor**: TCM Security
- **Prerequisites**: None
- **Validity**: Lifetime
- **Cost**: ~$400
- **Focus**: Real-world pentesting
- **Target Roles**: Pentester
- **Notes**: Full engagement simulation

## Advanced Offensive Certifications

### OSCP (Offensive Security Certified Professional)
- **Value**: 8/10
- **Vendor**: Offensive Security
- **Prerequisites**: Solid Linux/networking knowledge
- **Validity**: Lifetime
- **Cost**: ~$1,600
- **Focus**: Practical penetration testing
- **Target Roles**: Pentester, Red Team
- **Notes**: "Try Harder" - highly respected, 24-hour practical exam

### OSEP (Offensive Security Experienced Penetration Tester)
- **Value**: 9/10
- **Vendor**: Offensive Security
- **Prerequisites**: OSCP recommended
- **Validity**: Lifetime
- **Cost**: ~$1,600
- **Focus**: Advanced evasion, custom tools
- **Target Roles**: Senior Pentester, Red Team
- **Notes**: Advanced techniques, 48-hour exam

### OSWE (Offensive Security Web Expert)
- **Value**: 9/10
- **Vendor**: Offensive Security
- **Prerequisites**: Strong development background
- **Validity**: Lifetime
- **Cost**: ~$1,600
- **Focus**: Advanced web application security
- **Target Roles**: Web App Pentester
- **Notes**: Code review and exploitation

### OSCE3 (Offensive Security Certified Expert 3)
- **Value**: 10/10
- **Vendor**: Offensive Security
- **Prerequisites**: OSEP, OSWE, OSED
- **Validity**: Lifetime
- **Cost**: ~$5,000+ (3 certs)
- **Focus**: Mastery across offensive domains
- **Target Roles**: Lead Pentester, Red Team Lead
- **Notes**: Requires 3 advanced OffSec certs

## Defensive/Blue Team Certifications

### BTL1 (Blue Team Level 1)
- **Value**: 6/10
- **Vendor**: Security Blue Team
- **Prerequisites**: None
- **Validity**: 3 years
- **Cost**: ~$400
- **Focus**: SOC operations, SIEM, IR
- **Target Roles**: SOC Analyst

### CCD (Certified CyberDefender)
- **Value**: 7/10
- **Vendor**: Cybrary/CyberDefenders
- **Prerequisites**: None
- **Validity**: 3 years
- **Cost**: ~$500
- **Focus**: Defensive operations
- **Target Roles**: SOC Analyst, IR Analyst

### GCIH (GIAC Certified Incident Handler)
- **Value**: 7/10
- **Vendor**: GIAC/SANS
- **Prerequisites**: None (SANS training recommended)
- **Validity**: 4 years
- **Cost**: ~$2,000
- **Focus**: Incident response and handling
- **Target Roles**: Incident Responder

### GCIA (GIAC Certified Intrusion Analyst)
- **Value**: 7/10
- **Vendor**: GIAC/SANS
- **Prerequisites**: None
- **Validity**: 4 years
- **Cost**: ~$2,000
- **Focus**: Network traffic analysis, IDS
- **Target Roles**: SOC Analyst, Threat Hunter

### GCFA (GIAC Certified Forensic Analyst)
- **Value**: 8/10
- **Vendor**: GIAC/SANS
- **Prerequisites**: None
- **Validity**: 4 years
- **Cost**: ~$2,000
- **Focus**: Digital forensics
- **Target Roles**: Forensic Analyst

### GNFA (GIAC Network Forensic Analyst)
- **Value**: 7/10
- **Vendor**: GIAC/SANS
- **Prerequisites**: None
- **Validity**: 4 years
- **Cost**: ~$2,000
- **Focus**: Network forensics
- **Target Roles**: Forensic Analyst, IR

## Governance & Management Certifications

### CISSP (Certified Information Systems Security Professional)
- **Value**: 8/10
- **Vendor**: ISC2
- **Prerequisites**: 5 years experience (or 4 + degree)
- **Validity**: 3 years
- **Cost**: ~$750
- **Focus**: Security management, broad domains
- **Target Roles**: Security Manager, CISO, Consultant
- **Notes**: "Mile wide, inch deep" - management focused

### CISM (Certified Information Security Manager)
- **Value**: 7/10
- **Vendor**: ISACA
- **Prerequisites**: 5 years experience
- **Validity**: 3 years
- **Cost**: ~$600
- **Focus**: Information security governance
- **Target Roles**: Security Manager, CISO

### CISA (Certified Information Systems Auditor)
- **Value**: 7/10
- **Vendor**: ISACA
- **Prerequisites**: 5 years experience
- **Validity**: 3 years
- **Cost**: ~$600
- **Focus**: IT audit
- **Target Roles**: Auditor, Compliance Manager

### CRISC (Certified in Risk and Information Systems Control)
- **Value**: 6/10
- **Vendor**: ISACA
- **Prerequisites**: 3 years experience
- **Validity**: 3 years
- **Cost**: ~$600
- **Focus**: Risk management
- **Target Roles**: Risk Manager, GRC Analyst

## Cloud Security Certifications

### AWS Certified Security - Specialty
- **Value**: 7/10
- **Vendor**: Amazon Web Services
- **Prerequisites**: AWS Solutions Architect recommended
- **Validity**: 3 years
- **Cost**: ~$300
- **Focus**: AWS security services
- **Target Roles**: Cloud Security Engineer, AWS Security

### Microsoft Certified: Azure Security Engineer Associate
- **Value**: 7/10
- **Vendor**: Microsoft
- **Prerequisites**: Azure fundamentals
- **Validity**: 1 year
- **Cost**: ~$165
- **Focus**: Azure security
- **Target Roles**: Cloud Security Engineer

### Google Professional Cloud Security Engineer
- **Value**: 7/10
- **Vendor**: Google Cloud
- **Prerequisites**: GCP experience
- **Validity**: 2 years
- **Cost**: ~$200
- **Focus**: GCP security
- **Target Roles**: Cloud Security Engineer

### CCSP (Certified Cloud Security Professional)
- **Value**: 7/10
- **Vendor**: ISC2
- **Prerequisites**: 5 years IT, 3 years security
- **Validity**: 3 years
- **Cost**: ~$600
- **Focus**: Cloud security concepts (vendor-neutral)
- **Target Roles**: Cloud Security Architect

## Advanced GIAC Certifications

### GPEN (GIAC Penetration Tester)
- **Value**: 7/10
- **Cost**: ~$2,000
- **Focus**: Penetration testing

### GWAPT (GIAC Web Application Penetration Tester)
- **Value**: 7/10
- **Cost**: ~$2,000
- **Focus**: Web app pentesting

### GXPN (GIAC Exploit Researcher and Advanced Penetration Tester)
- **Value**: 9/10
- **Cost**: ~$2,000
- **Focus**: Advanced exploitation
- **Notes**: Very challenging

### GREM (GIAC Reverse Engineering Malware)
- **Value**: 8/10
- **Cost**: ~$2,000
- **Focus**: Malware analysis and reverse engineering

## Specialized Certifications

### CRTO (Certified Red Team Operator)
- **Value**: 8/10
- **Vendor**: Zero-Point Security
- **Focus**: Red team operations, Active Directory

### CRTP (Certified Red Team Professional)
- **Value**: 7/10
- **Vendor**: Pentester Academy
- **Focus**: Active Directory attacks

### ISO 27001 Lead Auditor/Implementer
- **Value**: 6/10
- **Vendor**: Various
- **Focus**: ISO 27001 standard

### SABSA (Sherwood Applied Business Security Architecture)
- **Value**: 7/10
- **Focus**: Security architecture methodology
- **Target Roles**: Security Architect

## Certification Value Summary

**Tier 1 (9-10)**: OSCE3, OSEP, OSWE, GXPN, GREM
**Tier 2 (7-8)**: OSCP, CISSP, GCFA, GPEN, CRTO, Cloud certs
**Tier 3 (5-6)**: CEH, eCPPT, CISM, CISA, BTL1
**Tier 4 (3-4)**: Security+, CySA+, PenTest+
